%% Code to create choropleth map for structure prices in the different US States over a given time period
%**************************************************************************
%% Code Starts Here:%%
%**************************************************************************
%Start with a blank workspace:
close all
clear all
clc
%% Reads data from excel file
[NumSte TxtSte RawSte]=xlsread('HouseLandPrices_MatlabInputData.xlsx','Structure'); % Structure Data

%% structrue cost Data
%Initializes map for US states
tic
figure; ax = usamap('all');
set(ax, 'Visible', 'off')
states = shaperead('usastatelo', 'UseGeoCoords', true);
NumSte=NumSte./1000; %express values in Thousands
% maxSte=max(max(NumSte)); %Uncomment theses 4 lines if want to fix scale or colorbar units but remember to comment out **
% minSte=min(min(NumSte));
% densityColors = makesymbolspec('Polygon', {'Ste', ...
%     [minSte maxSte], 'FaceColor', fall});

[r,c]=size(NumSte);
fall = flipud(autumn(numel(states)));
names = {states.Name};
indexHawaii = strcmp('Hawaii',names);
indexAlaska = strcmp('Alaska',names);
indexConus = 1:numel(states);
indexConus(indexHawaii|indexAlaska) = [];
StateAlphaOrder=TxtSte(2:end,1);
mkdir('Structure')

for j = 1:c
    for i = 1:r
        ind=find(strcmp(StateAlphaOrder,states(i).Name)); %sorts out data, doesn't need your data to be alphabetically ordered
        states(i,1).Ste=NumSte(ind,j);
    end
    minSte=min(NumSte(:,j)); % **
    maxSte=max(NumSte(:,j)); % **
    Date=TxtSte{1,j+1};
    TitStr=sprintf('Structure Costs in US by State in %s',Date);
    densityColors = makesymbolspec('Polygon', {'Ste', ... % **
        [minSte maxSte], 'FaceColor', fall}); % **
    
    geoshow(ax(1),states(indexConus), 'DisplayType', 'polygon', ...
        'SymbolSpec', densityColors)
    setm(ax(1), 'Frame', 'off', 'Grid', 'off',...
        'ParallelLabel', 'off', 'MeridianLabel', 'off') % turn off settings
    t=title (TitStr);
    set(t, 'FontSize', 10);
    caxis([minSte maxSte])
    colormap(fall)
    h=colorbar;
    ylabel(h, 'Structure Costs in Thousands')
    set(h,'FontSize',10);
    geoshow(ax(2),states(indexAlaska), 'DisplayType', 'polygon', ...
        'SymbolSpec', densityColors)
    setm(ax(2), 'Frame', 'off', 'Grid', 'off',...
        'ParallelLabel', 'off', 'MeridianLabel', 'off')
    
    geoshow(ax(3),states(indexHawaii), 'DisplayType', 'polygon', ...
        'SymbolSpec', densityColors)
    setm(ax(3), 'Frame', 'off', 'Grid', 'off',...
        'ParallelLabel', 'off', 'MeridianLabel', 'off')
%     set(gcf, 'units','normalized','outerposition',[0 0 1 1]); % full screen
    if j==1
        pause (0.05) % give it sometime for first figure to load before saving it, exclude from if statement if want it for all iterations
    end
    imagename=sprintf('%s\\Structure\\%d.jpg',pwd,j);
    saveas(gcf,imagename)
end
toc


