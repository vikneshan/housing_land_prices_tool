%% Code to create choropleth map for land prices in the different US States over a given time period
%**************************************************************************
%% Code Starts Here:%%
%**************************************************************************
%Start with a blank workspace:
close all
clear all
clc
%% Reads data from excel file
[NumLan TxtLan RawLan]=xlsread('HouseLandPrices_MatlabInputData.xlsx','Land'); % Land Data

%% Housing Data
%Initializes map for US states
tic
figure; ax = usamap('all');
set(ax, 'Visible', 'off')
states = shaperead('usastatelo', 'UseGeoCoords', true);
NumLan=NumLan./1000; %express values in Thousands
% maxlan=max(max(NumLan)); %Uncomment theses 4 lines if want to fix scale or colorbar units but remember to comment out **
% minlan=min(min(NumLan));
% densityColors = makesymbolspec('Polygon', {'Land', ...
%     [minlan maxlan], 'FaceColor', fall});

[r,c]=size(NumLan);
fall = flipud(autumn(numel(states)));
names = {states.Name};
indexHawaii = strcmp('Hawaii',names);
indexAlaska = strcmp('Alaska',names);
indexConus = 1:numel(states);
indexConus(indexHawaii|indexAlaska) = [];
StateAlphaOrder=TxtLan(2:end,1);
mkdir('Land')

for j = 1:c
    for i = 1:r
        ind=find(strcmp(StateAlphaOrder,states(i).Name)); %sorts out data, doesn't need your data to be alphabetically ordered
        states(i,1).Land=NumLan(ind,j);
    end
    minlan=min(NumLan(:,j)); % **
    maxlan=max(NumLan(:,j)); % **
    Date=TxtLan{1,j+1};
    TitStr=sprintf('Land Prices in US by State in %s',Date);
    densityColors = makesymbolspec('Polygon', {'Land', ... % **
        [minlan maxlan], 'FaceColor', fall}); % **
    
    geoshow(ax(1),states(indexConus), 'DisplayType', 'polygon', ...
        'SymbolSpec', densityColors)
    setm(ax(1), 'Frame', 'off', 'Grid', 'off',...
        'ParallelLabel', 'off', 'MeridianLabel', 'off') % turn off settings
    t=title (TitStr);
    set(t, 'FontSize', 10);
    caxis([minlan maxlan])
    colormap(fall)
    h=colorbar;
    ylabel(h, 'Land Price in Thousands')
    set(h,'FontSize',10);
    geoshow(ax(2),states(indexAlaska), 'DisplayType', 'polygon', ...
        'SymbolSpec', densityColors)
    setm(ax(2), 'Frame', 'off', 'Grid', 'off',...
        'ParallelLabel', 'off', 'MeridianLabel', 'off')
    
    geoshow(ax(3),states(indexHawaii), 'DisplayType', 'polygon', ...
        'SymbolSpec', densityColors)
    setm(ax(3), 'Frame', 'off', 'Grid', 'off',...
        'ParallelLabel', 'off', 'MeridianLabel', 'off')
%     set(gcf, 'units','normalized','outerposition',[0 0 1 1]); % full screen
    if j==1
        pause (0.05) % give it sometime for first figure to load before saving it, exclude from if statement if want it for all iterations
    end
    imagename=sprintf('%s\\Land\\%d.jpg',pwd,j);
    saveas(gcf,imagename)
end
toc


